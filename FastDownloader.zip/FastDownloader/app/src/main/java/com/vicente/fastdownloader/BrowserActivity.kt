package com.vicente.fastdownloader

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import java.net.URLEncoder

/**
 * Built-in browser: when a page triggers a download, it captures the link plus
 * the session (cookies, user agent, referer) and hands it to the fast downloader.
 */
class BrowserActivity : Activity() {

    companion object {
        const val EXTRA_START_URL = "start_url"
        private const val HOME_PAGE = "https://www.google.com"
    }

    private lateinit var webView: WebView
    private lateinit var addressBar: EditText
    private lateinit var pageProgress: ProgressBar
    private var threads = 8

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        threads = intent.getIntExtra(DownloadService.EXTRA_THREADS, 8)
        setContentView(buildLayout())

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false) // "open in new tab" links load here instead
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "http" || scheme == "https") return false
                // intent://, market://, etc. -> hand off to the system
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (_: ActivityNotFoundException) {
                } catch (_: SecurityException) {
                }
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!addressBar.hasFocus()) addressBar.setText(url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                pageProgress.progress = newProgress
                pageProgress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            captureDownload(url, userAgent, contentDisposition, mimeType)
        }

        val startUrl = intent.getStringExtra(EXTRA_START_URL)
        webView.loadUrl(if (startUrl.isNullOrBlank()) HOME_PAGE else startUrl)
    }

    private fun captureDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("Esta página arma el archivo dentro del navegador, no se puede acelerar")
            return
        }
        if (DownloadService.isRunning) {
            toast("Ya hay una descarga en curso")
            return
        }
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        startForegroundService(
            Intent(this, DownloadService::class.java)
                .putExtra(DownloadService.EXTRA_URL, url)
                .putExtra(DownloadService.EXTRA_THREADS, threads)
                .putExtra(DownloadService.EXTRA_COOKIES, CookieManager.getInstance().getCookie(url))
                .putExtra(DownloadService.EXTRA_USER_AGENT, userAgent)
                .putExtra(DownloadService.EXTRA_REFERER, webView.url)
                .putExtra(DownloadService.EXTRA_FILE_NAME, fileName)
        )
        toast("✅ Descarga capturada: $fileName\nMira el progreso en la notificación")
    }

    private fun navigate() {
        val text = addressBar.text.toString().trim()
        if (text.isEmpty()) return
        val target = when {
            text.contains("://") -> text
            text.contains('.') && !text.contains(' ') -> "https://$text"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8")
        }
        webView.loadUrl(target)
        addressBar.clearFocus()
        getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(addressBar.windowToken, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun buildLayout(): LinearLayout {
        val pad = dp(6)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(32), 0, 0)
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        addressBar = EditText(this).apply {
            hint = "Busca o escribe una dirección"
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) { navigate(); true } else false
            }
        }
        topBar.addView(addressBar, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(Button(this).apply {
            text = "Ir"
            setOnClickListener { navigate() }
        })
        root.addView(topBar)

        pageProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(pageProgress, LinearLayout.LayoutParams.MATCH_PARENT, dp(4))

        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
