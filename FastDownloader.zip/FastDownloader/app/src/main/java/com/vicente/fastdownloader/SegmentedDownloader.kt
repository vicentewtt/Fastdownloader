package com.vicente.fastdownloader

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/**
 * Multi-connection downloader: splits the file into byte ranges and downloads
 * them in parallel (like IDM / ADM), writing each part at its offset.
 */
class SegmentedDownloader(
    private val url: String,
    threads: Int,
    private val cookies: String? = null,
    private val userAgent: String? = null,
    private val referer: String? = null,
    private val fileNameHint: String? = null
) {

    // Cookies are only sent to the site they came from, never to other hosts after a redirect
    private val cookieHost: String? = runCatching { URL(url).host }.getOrNull()

    data class Info(
        val url: String,
        val size: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String?
    )

    companion object {
        const val MAX_THREADS = 32
        private const val MIN_SPLIT_SIZE = 2L * 1024 * 1024
        private const val BUFFER_SIZE = 256 * 1024
        private const val MAX_RETRIES = 6
        private const val MAX_REDIRECTS = 10
        private const val PROGRESS_INTERVAL_MS = 500L
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36"
    }

    private val threadCount = threads.coerceIn(1, MAX_THREADS)
    private val openConnections = ConcurrentLinkedQueue<HttpURLConnection>()
    private val active = AtomicInteger(0)

    @Volatile var cancelled = false
        private set
    @Volatile private var stopped = false

    val activeConnections: Int get() = active.get()

    fun cancel() {
        cancelled = true
        stopAll()
    }

    private fun stopAll() {
        stopped = true
        openConnections.forEach { runCatching { it.disconnect() } }
    }

    /** Opens a connection following redirects manually (also http -> https). */
    private fun open(target: String, range: String?): HttpURLConnection {
        var current = target
        repeat(MAX_REDIRECTS) {
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 15_000
                readTimeout = 30_000
                setRequestProperty("User-Agent", userAgent ?: USER_AGENT)
                setRequestProperty("Accept-Encoding", "identity")
                if (referer != null) setRequestProperty("Referer", referer)
                if (cookies != null && URL(current).host == cookieHost) setRequestProperty("Cookie", cookies)
                if (range != null) setRequestProperty("Range", range)
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location == null) throw IOException("Redirección sin destino")
                current = URL(URL(current), location).toString()
                return@repeat
            }
            if (code >= 400) {
                conn.disconnect()
                throw IOException("El servidor respondió HTTP $code")
            }
            return conn
        }
        throw IOException("Demasiadas redirecciones")
    }

    /** Checks size, range support and file name before downloading. */
    fun probe(): Info {
        val conn = open(url, "bytes=0-")
        try {
            val total: Long
            val ranges: Boolean
            if (conn.responseCode == 206) {
                total = conn.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull() ?: -1L
                ranges = total > 0
            } else {
                total = conn.contentLengthLong
                ranges = false
            }
            val name = fileNameFrom(conn.getHeaderField("Content-Disposition"), conn.url)
            val mime = conn.contentType?.substringBefore(';')?.trim()
            return Info(conn.url.toString(), total, ranges, name, mime)
        } finally {
            conn.disconnect()
        }
    }

    fun download(
        info: Info,
        channel: FileChannel,
        onProgress: (done: Long, total: Long, bytesPerSecond: Long) -> Unit
    ) {
        val counter = AtomicLong(0)
        val errors = ConcurrentLinkedQueue<Throwable>()
        val split = info.supportsRanges && info.size >= MIN_SPLIT_SIZE && threadCount > 1

        fun worker(name: String, job: () -> Unit) = thread(name = name) {
            try {
                job()
            } catch (t: Throwable) {
                errors.add(t)
                stopAll()
            }
        }

        val workers = if (split) {
            val chunk = info.size / threadCount
            (0 until threadCount).map { i ->
                val start = i * chunk
                val end = if (i == threadCount - 1) info.size - 1 else start + chunk - 1
                worker("segment-$i") { fetchRange(info.url, start, end, channel, counter) }
            }
        } else {
            listOf(worker("segment-0") { fetchStream(info.url, channel, counter) })
        }

        var lastBytes = 0L
        var lastTime = System.nanoTime()
        var smoothedSpeed = 0.0
        while (workers.any { it.isAlive }) {
            Thread.sleep(PROGRESS_INTERVAL_MS)
            val now = System.nanoTime()
            val bytes = counter.get()
            val instant = (bytes - lastBytes) * 1e9 / (now - lastTime).coerceAtLeast(1)
            smoothedSpeed = if (smoothedSpeed == 0.0) instant else smoothedSpeed * 0.6 + instant * 0.4
            lastBytes = bytes
            lastTime = now
            onProgress(bytes, info.size, smoothedSpeed.toLong())
        }

        if (cancelled) throw IOException("Cancelado")
        errors.firstOrNull()?.let { throw it }
        if (info.size > 0 && counter.get() < info.size) throw IOException("Descarga incompleta")
    }

    /** Downloads one byte range, resuming from where it stopped on errors. */
    private fun fetchRange(target: String, start: Long, end: Long, channel: FileChannel, counter: AtomicLong) {
        var position = start
        var attempts = 0
        val buffer = ByteArray(BUFFER_SIZE)
        while (position <= end) {
            if (stopped) throw IOException("Detenido")
            try {
                val conn = open(target, "bytes=$position-$end")
                openConnections.add(conn)
                active.incrementAndGet()
                try {
                    if (conn.responseCode != 206) throw IOException("El servidor no respetó el rango")
                    conn.inputStream.use { input ->
                        while (position <= end) {
                            if (stopped) throw IOException("Detenido")
                            val max = minOf(BUFFER_SIZE.toLong(), end - position + 1).toInt()
                            val read = input.read(buffer, 0, max)
                            if (read < 0) break
                            writeAt(channel, buffer, read, position)
                            position += read
                            counter.addAndGet(read.toLong())
                        }
                    }
                } finally {
                    active.decrementAndGet()
                    openConnections.remove(conn)
                    conn.disconnect()
                }
                if (position <= end) throw IOException("Conexión cortada")
            } catch (e: IOException) {
                if (stopped || ++attempts > MAX_RETRIES) throw e
                Thread.sleep(1000L * attempts)
            }
        }
    }

    /** Fallback when the server doesn't support ranges: one single connection. */
    private fun fetchStream(target: String, channel: FileChannel, counter: AtomicLong) {
        val conn = open(target, null)
        openConnections.add(conn)
        active.incrementAndGet()
        try {
            conn.inputStream.use { input ->
                val buffer = ByteArray(BUFFER_SIZE)
                var position = 0L
                while (true) {
                    if (stopped) throw IOException("Detenido")
                    val read = input.read(buffer)
                    if (read < 0) break
                    writeAt(channel, buffer, read, position)
                    position += read
                    counter.addAndGet(read.toLong())
                }
            }
        } finally {
            active.decrementAndGet()
            openConnections.remove(conn)
            conn.disconnect()
        }
    }

    /** Positional write: thread-safe on a shared FileChannel. */
    private fun writeAt(channel: FileChannel, buffer: ByteArray, length: Int, position: Long) {
        val bb = ByteBuffer.wrap(buffer, 0, length)
        var p = position
        while (bb.hasRemaining()) p += channel.write(bb, p)
    }

    private fun fileNameFrom(disposition: String?, url: URL): String {
        var name: String? = null
        if (disposition != null) {
            Regex("filename\\*\\s*=\\s*(?:UTF-8'[^']*')?([^;]+)", RegexOption.IGNORE_CASE)
                .find(disposition)?.let { m ->
                    name = runCatching { URLDecoder.decode(m.groupValues[1].trim().trim('"'), "UTF-8") }.getOrNull()
                }
            if (name.isNullOrBlank()) {
                Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE)
                    .find(disposition)?.let { m -> name = m.groupValues[1].trim() }
            }
        }
        if (name.isNullOrBlank()) name = fileNameHint
        if (name.isNullOrBlank()) {
            val lastSegment = url.path.substringAfterLast('/').replace("+", "%2B")
            name = runCatching { URLDecoder.decode(lastSegment, "UTF-8") }.getOrNull()
        }
        val clean = name.orEmpty()
            .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
            .trim()
            .take(150)
        return clean.ifBlank { "descarga_${System.currentTimeMillis()}" }
    }
}

fun formatBytes(bytes: Long): String {
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = 0
    while (value >= 1024 && unit < units.lastIndex) {
        value /= 1024
        unit++
    }
    return String.format(Locale("es", "CL"), "%.1f %s", value, units[unit])
}

fun formatSpeed(bytesPerSecond: Long): String {
    val megabytes = bytesPerSecond / (1024.0 * 1024.0)
    val megabits = bytesPerSecond * 8 / 1_000_000.0
    return String.format(Locale("es", "CL"), "%.1f MB/s (%.0f Mbps)", megabytes, megabits)
}
