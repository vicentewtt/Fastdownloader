package com.vicente.fastdownloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.FileOutputStream
import kotlin.concurrent.thread

/** Foreground service: keeps downloading with the screen off or the app closed. */
class DownloadService : Service() {

    data class Status(val text: String, val progress: Int, val finished: Boolean)

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_THREADS = "threads"
        const val EXTRA_COOKIES = "cookies"
        const val EXTRA_USER_AGENT = "user_agent"
        const val EXTRA_REFERER = "referer"
        const val EXTRA_FILE_NAME = "file_name"
        const val ACTION_CANCEL = "com.vicente.fastdownloader.CANCEL"
        private const val CHANNEL_ID = "downloads"
        private const val NOTIFICATION_ID = 1

        @Volatile var isRunning = false
            private set
        @Volatile var lastStatus: Status? = null
            private set
        var listener: ((Status) -> Unit)? = null
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var downloader: SegmentedDownloader? = null
    private lateinit var notificationManager: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Descargas", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            downloader?.cancel()
            return START_NOT_STICKY
        }

        val startIntent = intent ?: return START_NOT_STICKY

        startForeground(
            NOTIFICATION_ID,
            buildNotification("Conectando…", 0, indeterminate = true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        val url = startIntent.getStringExtra(EXTRA_URL)
        if (url == null || isRunning) {
            if (!isRunning) stopSelf()
            return START_NOT_STICKY
        }

        val threads = startIntent.getIntExtra(EXTRA_THREADS, 8)
        isRunning = true
        val dl = SegmentedDownloader(
            url = url,
            threads = threads,
            cookies = startIntent.getStringExtra(EXTRA_COOKIES),
            userAgent = startIntent.getStringExtra(EXTRA_USER_AGENT),
            referer = startIntent.getStringExtra(EXTRA_REFERER),
            fileNameHint = startIntent.getStringExtra(EXTRA_FILE_NAME)
        )
        downloader = dl
        thread(name = "download-main") { runDownload(dl, threads) }
        return START_NOT_STICKY
    }

    private fun runDownload(dl: SegmentedDownloader, threads: Int) {
        // High-performance Wi-Fi lock: stops Android from throttling Wi-Fi to save battery
        @Suppress("DEPRECATION")
        val wifiLock = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "fastdl:wifi")
        val wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fastdl:cpu")
        wifiLock.acquire()
        wakeLock.acquire(6 * 60 * 60 * 1000L)

        var uri: Uri? = null

        val result: Status = try {
            publish(Status("Conectando…", 0, false))
            val info = dl.probe()

            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, info.fileName)
                put(MediaStore.Downloads.IS_PENDING, 1)
                mimeFor(info)?.let { put(MediaStore.Downloads.MIME_TYPE, it) }
            }
            val target = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("No se pudo crear el archivo en Descargas")
            uri = target

            val modeText = if (info.supportsRanges) "${threads.coerceIn(1, SegmentedDownloader.MAX_THREADS)} conexiones"
                           else "1 conexión (el servidor no permite dividir)"

            contentResolver.openFileDescriptor(target, "rw")!!.use { pfd ->
                val channel = FileOutputStream(pfd.fileDescriptor).channel
                dl.download(info, channel) { done, total, speed ->
                    val percent = if (total > 0) (done * 100 / total).toInt() else 0
                    val text = buildString {
                        append(formatBytes(done))
                        if (total > 0) append(" / ").append(formatBytes(total)).append("  ($percent%)")
                        append("\n").append(formatSpeed(speed))
                        append("\n").append(modeText).append(" • activas: ").append(dl.activeConnections)
                    }
                    publish(Status(text, percent, false))
                    notificationManager.notify(NOTIFICATION_ID, buildNotification(text, percent, total <= 0))
                }
            }

            contentResolver.update(target, ContentValues().apply {
                put(MediaStore.Downloads.IS_PENDING, 0)
            }, null, null)

            Status("✅ Listo: ${info.fileName}\nGuardado en Descargas", 100, true)
        } catch (e: Exception) {
            uri?.let { runCatching { contentResolver.delete(it, null, null) } }
            val message = if (dl.cancelled) "Descarga cancelada"
                          else "❌ Error: ${e.message ?: e.javaClass.simpleName}"
            Status(message, 0, true)
        } finally {
            if (wifiLock.isHeld) wifiLock.release()
            if (wakeLock.isHeld) wakeLock.release()
            downloader = null
            isRunning = false
        }

        publish(result)
        mainHandler.post {
            stopForeground(STOP_FOREGROUND_DETACH)
            notificationManager.notify(NOTIFICATION_ID, buildNotification(result.text, 100, false, ongoing = false))
            stopSelf()
        }
    }

    private fun mimeFor(info: SegmentedDownloader.Info): String? {
        val ext = info.fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: info.mimeType?.takeIf { ext.isEmpty() && it != "application/octet-stream" }
    }

    private fun publish(status: Status) {
        lastStatus = status
        mainHandler.post { listener?.invoke(status) }
    }

    private fun buildNotification(
        text: String,
        progress: Int,
        indeterminate: Boolean,
        ongoing: Boolean = true
    ): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(
                if (ongoing) android.R.drawable.stat_sys_download
                else android.R.drawable.stat_sys_download_done
            )
            .setContentTitle("Descargador rápido")
            .setContentText(text.substringBefore('\n'))
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)

        if (ongoing) {
            builder.setProgress(100, progress, indeterminate)
            val cancelIntent = PendingIntent.getService(
                this, 1,
                Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(Notification.Action.Builder(null as Icon?, "Cancelar", cancelIntent).build())
        }
        return builder.build()
    }
}
