package com.vicente.fastdownloader

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var urlInput: EditText
    private lateinit var threadsInput: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildLayout())

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        handleShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShareIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        DownloadService.lastStatus?.let(::render)
        DownloadService.listener = ::render
    }

    override fun onPause() {
        super.onPause()
        DownloadService.listener = null
    }

    private fun render(status: DownloadService.Status) {
        progressBar.progress = status.progress
        statusText.text = status.text
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        extractUrl(text)?.let { urlInput.setText(it) }
    }

    private fun extractUrl(text: String): String? = Regex("https?://\\S+").find(text)?.value

    private fun startDownload() {
        if (DownloadService.isRunning) {
            toast("Ya hay una descarga en curso")
            return
        }
        val url = extractUrl(urlInput.text.toString().trim()) ?: run {
            toast("Pega un link válido (http o https)")
            return
        }
        val threads = readThreads()

        startForegroundService(
            Intent(this, DownloadService::class.java)
                .putExtra(DownloadService.EXTRA_URL, url)
                .putExtra(DownloadService.EXTRA_THREADS, threads)
        )
        progressBar.progress = 0
        statusText.text = "Iniciando…"
    }

    private fun openBrowser() {
        val startUrl = extractUrl(urlInput.text.toString().trim())
        startActivity(
            Intent(this, BrowserActivity::class.java)
                .putExtra(DownloadService.EXTRA_THREADS, readThreads())
                .putExtra(BrowserActivity.EXTRA_START_URL, startUrl)
        )
    }

    private fun readThreads(): Int =
        threadsInput.text.toString().toIntOrNull()?.coerceIn(1, SegmentedDownloader.MAX_THREADS) ?: 8

    private fun cancelDownload() {
        if (!DownloadService.isRunning) return
        startService(Intent(this, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))
    }

    private fun pasteFromClipboard() {
        val clip = getSystemService(ClipboardManager::class.java).primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
        urlInput.setText(extractUrl(text) ?: text)
    }

    private fun buildLayout(): ScrollView {
        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 3, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Descargador rápido"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })

        root.addView(Button(this).apply {
            text = "🌐 Abrir navegador"
            setOnClickListener { openBrowser() }
        }, MATCH_PARENT, WRAP_CONTENT)

        root.addView(label("…o pega el link directo del archivo"))
        urlInput = EditText(this).apply {
            hint = "https://…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 4
        }
        root.addView(urlInput, MATCH_PARENT, WRAP_CONTENT)
        root.addView(Button(this).apply {
            text = "Pegar link"
            setOnClickListener { pasteFromClipboard() }
        }, MATCH_PARENT, WRAP_CONTENT)

        root.addView(label("Conexiones simultáneas (1–32)"))
        threadsInput = EditText(this).apply {
            setText("8")
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        root.addView(threadsInput, MATCH_PARENT, WRAP_CONTENT)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply {
            text = "Descargar"
            setOnClickListener { startDownload() }
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        buttons.addView(Button(this).apply {
            text = "Cancelar"
            setOnClickListener { cancelDownload() }
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        root.addView(buttons, MATCH_PARENT, WRAP_CONTENT)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(progressBar, MATCH_PARENT, WRAP_CONTENT)

        statusText = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(statusText, MATCH_PARENT, WRAP_CONTENT)

        return ScrollView(this).apply { addView(root) }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
